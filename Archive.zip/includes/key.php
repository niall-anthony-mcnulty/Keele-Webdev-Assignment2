<?php 
$apiKey = 'ca3c995a6eebe56bd7a6d2e8dfbf1f55';

?>